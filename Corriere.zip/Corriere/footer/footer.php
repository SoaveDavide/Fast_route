<?php
?>
</div>
<footer>
    <div class="bg-dark py-5 mt-5 text-center rounded-3">
        <p class="display-6 mb-3 text-white">Davide Soave 5-E</p>
        <small class="text-white-50">&copy; 2025 Fast Route. All rights reserved.</small>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
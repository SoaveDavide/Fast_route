<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
// Verifica che i dati siano stati inviati
if ($_SERVER["REQUEST_METHOD"] === "POST" ) {

    $mittente = filter_var($_POST['mittente'] );
    $body = htmlspecialchars($_POST['object']);
    require '../vendor/autoload.php';

    $mail = new PHPMailer(true);

    try {
        // Configurazione del server SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'davide.soave@iisviolamarchesini.edu.it';
        $mail->Password = 'zpsn vywh exoy nioy';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Mittente e destinatario
        $mail->setFrom($mittente);
        $mail->addAddress('davide.soave@iisviolamarchesini.edu.it');
        // Contenuto dell'email
        $mail->Subject = 'Recensione dal sito';
        $mail->Body = $body;
        $mail->CharSet = 'UTF-8';
        $mail->Encoding = 'base64';

        // Invio dell'email
        $mail->send();
        echo 'Email inviata con successo!';
    } catch (Exception $e) {
        echo "Errore nell'invio dell'email: {$mail->ErrorInfo}";
    }
} else {
    echo "Errore: dati non ricevuti.";
}
